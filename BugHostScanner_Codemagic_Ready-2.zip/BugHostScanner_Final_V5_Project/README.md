# Bug Host Scanner V5

Aplikasi Android sederhana untuk memeriksa resolusi DNS dan respons HTTP/HTTPS dari host yang dimasukkan pengguna.

## Build
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Kotlin 2.0.21
- JDK 17
- Jalankan: `gradle assembleDebug`
- APK: `app/build/outputs/apk/debug/app-debug.apk`

## Catatan
Gunakan hanya pada domain/host milik sendiri atau yang Anda punya izin untuk uji. Status "terhubung" berarti host berhasil memberikan respons HTTP, bukan bukti bahwa host aman atau dapat digunakan untuk tujuan tertentu.
