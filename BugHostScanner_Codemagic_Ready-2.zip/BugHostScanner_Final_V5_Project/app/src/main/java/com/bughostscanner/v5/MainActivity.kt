package com.bughostscanner.v5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.InetAddress
import java.util.Locale

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B293B)
private val Accent = Color(0xFF4DD0E1)
private val Muted = Color(0xFF9FB0C4)

data class ScanResult(
    val host: String,
    val ip: String?,
    val status: String,
    val detail: String,
    val latency: Long?
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BugHostScannerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BugHostScannerApp() {
    var host by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    var history by remember { mutableStateOf(listOf<ScanResult>()) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Navy,
            surface = Panel,
            onPrimary = Navy,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Navy) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BugReport, null, tint = Accent, modifier = Modifier.size(38.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("BUG HOST SCANNER", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                            Text("VERSION 5.0  •  HOST CONNECTIVITY TOOL", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Periksa host", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Masukkan domain atau alamat host yang ingin Anda uji.", color = Muted, fontSize = 13.sp)
                            OutlinedTextField(
                                value = host,
                                onValueChange = { host = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("contoh.com atau https://contoh.com") },
                                leadingIcon = { Icon(Icons.Default.Language, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Accent,
                                    unfocusedBorderColor = Muted,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            Button(
                                onClick = {
                                    error = null
                                    result = null
                                    scanning = true
                                    scope.launch {
                                        val scanned = withContext(Dispatchers.IO) { scanHost(host) }
                                        result = scanned
                                        history = listOf(scanned) + history.take(9)
                                        scanning = false
                                    }
                                },
                                enabled = !scanning && host.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Navy)
                            ) {
                                if (scanning) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Navy)
                                    Spacer(Modifier.width(10.dp))
                                    Text("MEMERIKSA...")
                                } else {
                                    Icon(Icons.Default.PlayArrow, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("MULAI SCAN", fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("Gunakan hanya pada host yang Anda miliki atau diizinkan untuk diuji.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Text("HASIL PEMINDAIAN", color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    if (result == null) {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Text("Belum ada hasil. Masukkan host lalu tekan MULAI SCAN.", Modifier.padding(16.dp), color = Muted)
                        }
                    } else {
                        ResultCard(result!!)
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("RIWAYAT TERAKHIR", color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { history = emptyList() }) {
                            Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                            Text("Hapus")
                        }
                    }
                }
                if (history.isEmpty()) {
                    item { Text("Riwayat masih kosong.", color = Muted, fontSize = 12.sp) }
                } else {
                    items(history) { item -> ResultCard(item, compact = true) }
                }
            }
        }
    }
}

@Composable
private fun ResultCard(item: ScanResult, compact: Boolean = false) {
    val good = item.status == "TERHUBUNG"
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.host, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Surface(color = if (good) Color(0xFF164E42) else Color(0xFF633333), shape = RoundedCornerShape(50)) {
                    Text(item.status, color = if (good) Color(0xFF8AF0C5) else Color(0xFFFFB4AB),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (!compact) {
                Text("IP: ${item.ip ?: "Tidak ditemukan"}", color = Muted, fontSize = 12.sp)
                Text(item.detail, color = Color.White, fontSize = 13.sp)
                Text("Waktu respons: ${item.latency?.let { "$it ms" } ?: "-"}", color = Muted, fontSize = 12.sp)
            } else {
                Text(item.detail, color = Muted, fontSize = 11.sp, maxLines = 2)
            }
        }
    }
}

private fun scanHost(raw: String): ScanResult {
    val cleaned = raw.trim()
    if (cleaned.isEmpty()) return ScanResult("-", null, "GAGAL", "Host belum diisi.", null)
    val normalized = if (cleaned.contains("://")) cleaned else "https://$cleaned"
    val parsed = try { URL(normalized) } catch (_: Exception) {
        return ScanResult(cleaned, null, "GAGAL", "Format host tidak valid.", null)
    }
    val hostname = parsed.host ?: return ScanResult(cleaned, null, "GAGAL", "Nama host tidak valid.", null)
    if (hostname.isBlank() || hostname.contains(" ")) {
        return ScanResult(cleaned, null, "GAGAL", "Nama host tidak valid.", null)
    }
    val ip = try { InetAddress.getByName(hostname).hostAddress } catch (_: Exception) { null }
    if (ip == null) return ScanResult(hostname, null, "TIDAK AKTIF", "DNS gagal: host tidak dapat ditemukan.", null)

    val schemes = listOf("https", "http")
    var lastDetail = "Tidak mendapat respons HTTP."
    for (scheme in schemes) {
        val start = System.currentTimeMillis()
        var connection: HttpURLConnection? = null
        try {
            val portPart = if (parsed.port != -1) ":${parsed.port}" else ""
            val path = if (parsed.file.isNullOrBlank()) "/" else parsed.file
            connection = (URL("$scheme://$hostname$portPart$path").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "BugHostScanner/5.0")
            }
            val code = connection.responseCode
            val elapsed = System.currentTimeMillis() - start
            lastDetail = "HTTP $code • server memberikan respons."
            return ScanResult(hostname, ip, "TERHUBUNG", lastDetail, elapsed)
        } catch (e: Exception) {
            lastDetail = e.message ?: "Koneksi gagal."
        } finally {
            connection?.disconnect()
        }
    }
    return ScanResult(hostname, ip, "TIDAK TERHUBUNG", lastDetail, null)
}
