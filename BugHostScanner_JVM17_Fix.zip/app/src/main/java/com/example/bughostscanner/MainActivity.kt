package com.example.bughostscanner

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.content.Intent
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.net.InetSocketAddress
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.concurrent.thread
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bug_host_scanner", MODE_PRIVATE) }
    private val bg = Color.rgb(14, 18, 25)
    private val panel = Color.rgb(25, 32, 43)
    private val mint = Color.rgb(65, 220, 164)
    private lateinit var domains: EditText
    private lateinit var output: TextView
    private lateinit var operator: Spinner
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var liveOnly: CheckBox
    private val scanning = AtomicBoolean(false)
    private val results = mutableListOf<String>()
    private val executor = Executors.newFixedThreadPool(8)

    // Starter list: ordinary public domains for connectivity diagnostics, not carrier bypass hosts.
    private val presets = listOf(
        "google.com", "www.google.com", "youtube.com", "www.youtube.com",
        "cloudflare.com", "www.cloudflare.com", "microsoft.com", "www.microsoft.com",
        "apple.com", "www.apple.com", "github.com", "www.github.com",
        "wikipedia.org", "www.wikipedia.org", "facebook.com", "www.facebook.com",
        "instagram.com", "www.instagram.com", "whatsapp.com", "www.whatsapp.com",
        "telegram.org", "www.telegram.org", "amazon.com", "www.amazon.com",
        "netflix.com", "www.netflix.com", "spotify.com", "www.spotify.com",
        "reddit.com", "www.reddit.com", "tiktok.com", "www.tiktok.com",
        "mozilla.org", "www.mozilla.org", "fast.com", "www.fast.com",
        "speedtest.net", "www.speedtest.net", "openai.com", "www.openai.com"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 16); setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "BUG HOST SCANNER"; textSize = 25f; setTextColor(mint); typeface = Typeface.DEFAULT_BOLD
        })
        content.addView(label("V2 • Multi-domain HTTP / HTTPS / TLS diagnostics"))
        operator = Spinner(this)
        operator.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Jaringan: Telkomsel", "Jaringan: AXIS", "Jaringan: XL", "Jaringan: lainnya"))
        content.addView(operator)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        content.addView(progress, LinearLayout.LayoutParams(-1, 8))
        val preset = button("ISI 40 DOMAIN TES", mint)
        content.addView(preset)
        content.addView(label("Domain (satu per baris)"))
        domains = EditText(this).apply {
            hint = "example.com"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setBackgroundColor(panel); minLines = 5; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(12, 12, 12, 12)
        }
        content.addView(domains, LinearLayout.LayoutParams(-1, 160))
        liveOnly = CheckBox(this).apply {
            text = "Tampilkan hanya hasil yang merespons"; setTextColor(Color.WHITE)
        }
        content.addView(liveOnly)
        val row = LinearLayout(this)
        val scan = button("SCAN", mint); val stop = button("STOP", Color.rgb(240,90,90))
        val export = button("EXPORT", Color.rgb(90,150,230))
        row.addView(scan, lp()); row.addView(stop, lp()); row.addView(export, lp()); content.addView(row)
        status = label("Siap • Scan memakai koneksi internet aktif HP")
        content.addView(status)
        content.addView(label("HASIL"))
        output = TextView(this).apply {
            text = "Belum ada hasil."; setTextColor(Color.WHITE); textSize = 13f
            setBackgroundColor(panel); setPadding(12, 12, 12, 12)
        }
        content.addView(output)
        content.addView(label("RIWAYAT SCAN TERAKHIR"))
        val historyView = TextView(this).apply {
            text = prefs.getString("history", "Belum ada riwayat.")
            setTextColor(Color.LTGRAY); textSize = 12f; setBackgroundColor(panel); setPadding(12,12,12,12)
        }
        content.addView(historyView)
        val clearHistory = button("HAPUS RIWAYAT", Color.rgb(100,110,125))
        content.addView(clearHistory)
        clearHistory.setOnClickListener {
            prefs.edit().remove("history").apply()
            historyView.text = "Belum ada riwayat."
            toast("Riwayat dihapus")
        }
        content.addView(label("LIVE = respons koneksi normal, bukan bukti kompatibilitas tunnel/kuota."))
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)

        preset.setOnClickListener { domains.setText(presets.joinToString("\n")) }
        scan.setOnClickListener { startScan() }
        stop.setOnClickListener { scanning.set(false); status.text = "Menghentikan scan..." }
        export.setOnClickListener {
            val txt = results.joinToString("\n")
            if (txt.isBlank()) { toast("Belum ada hasil"); return@setOnClickListener }
            val send = Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_SUBJECT,"Bug Host Scanner V2"); putExtra(Intent.EXTRA_TEXT,txt) }
            startActivity(Intent.createChooser(send,"Ekspor / bagikan hasil"))
        }
    }

    private fun startScan() {
        if (!scanning.compareAndSet(false,true)) return
        val hosts = domains.text.toString().lines().map { normalize(it) }.filter { it.isNotBlank() }.distinct()
        if (hosts.isEmpty()) { scanning.set(false); toast("Masukkan domain"); return }
        results.clear(); output.text = ""; status.text = "Scan 0/${hosts.size}"
        runOnUiThread { progress.max = hosts.size; progress.progress = 0 }
        thread {
            var done=0
            for (host in hosts) {
                if (!scanning.get()) break
                val line = checkHost(host)
                synchronized(results) { results.add(line) }
                done++
                runOnUiThread {
                    status.text = "Scan $done/${hosts.size}"
                    if (!liveOnly.isChecked || line.contains("LIVE")) output.append(line+"\n")
                }
            }
            scanning.set(false)
            val summary = results.joinToString("\\n")
            prefs.edit().putString("history", summary.take(12000)).apply()
            runOnUiThread {
                status.text = "Selesai • ${results.size} domain diperiksa"
                toast("Scan selesai")
            }
        }
    }

    private fun normalize(s: String): String = s.trim().removePrefix("https://").removePrefix("http://").substringBefore("/").substringBefore(":")
    private fun checkHost(host: String): String {
        if (!host.matches(Regex("(?i)[a-z0-9.-]+")) || host.startsWith(".") || host.endsWith(".") || host.contains(".."))
            return "$host | INVALID"
        var tls = false
        var tlsInfo = "TLS FAIL"
        try {
            val socket = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket() as SSLSocket
            socket.soTimeout=4000; socket.connect(InetSocketAddress(host,443),4000)
            socket.startHandshake(); tls=true; tlsInfo="TLS OK"; socket.close()
        } catch (_: Exception) {}
        var code: Int? = null
        var proto = "HTTPS"
        try {
            val c=URL("https://$host").openConnection() as HttpURLConnection
            c.connectTimeout=4000; c.readTimeout=4000; c.requestMethod="HEAD"; c.instanceFollowRedirects=false
            code=c.responseCode; c.disconnect()
        } catch (_: Exception) {
            proto="HTTP"
            try {
                val c=URL("http://$host").openConnection() as HttpURLConnection
                c.connectTimeout=3000; c.readTimeout=3000; c.requestMethod="HEAD"; c.instanceFollowRedirects=false
                code=c.responseCode; c.disconnect()
            } catch (_: Exception) {}
        }
        val live = tls || code != null
        val state = if(live) "LIVE" else "TIMEOUT/ERROR"
        return "$host | $state | $tlsInfo | ${if(code!=null) "$proto $code" else "$proto NO RESPONSE"}"
    }
    private fun label(s:String)=TextView(this).apply { text=s; setTextColor(Color.LTGRAY); textSize=13f; setPadding(0,12,0,7) }
    private fun button(s:String,c:Int)=Button(this).apply { text=s; textSize=11f; setTextColor(bg); setBackgroundColor(c) }
    private fun lp()=LinearLayout.LayoutParams(0,50,1f).apply { setMargins(3,6,3,6) }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use {
                    domains.setText(it.readText())
                }
                toast("Daftar domain berhasil diimpor")
            } catch (e: Exception) { toast("Gagal membaca file TXT") }
        }
    }
    override fun onDestroy(){ scanning.set(false); executor.shutdownNow(); super.onDestroy() }
}
