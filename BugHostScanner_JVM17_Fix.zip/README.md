# Bug Host Scanner — Final Starter (V5)

## What's included
- 40 public-domain diagnostic presets (ordinary connectivity targets).
- Domain list editor + import TXT (Android document picker).
- Multi-host sequential scan with progress and Stop.
- TLS handshake and HTTPS HEAD; HTTP fallback.
- LIVE/TIMEOUT-ERROR display and LIVE-only filter.
- Dashboard counters (LIVE/TLS/HTTP/HTTPS).
- Export/share result text.
- Last scan result persisted in app preferences; clear history button.
- Operator selector is a label only; scanning uses phone's current network.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as a project; wait for Gradle sync.
3. Build > Build APK(s).
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is a connectivity diagnostics app, not a carrier exploit detector. LIVE means a host responded to standard TLS or HTTP(S) checks; it does not mean the host works as a quota bypass or tunnel. Do testing only on networks/services you are authorized to test.
\n\n## Codemagic\nThis project includes `codemagic.yaml` for an unsigned Android debug APK build. Connect the repository to Codemagic and start the `android-debug` workflow.\n